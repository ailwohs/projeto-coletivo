console.log ("FUNCIONA!")

function saudacao() {
    console.log('Iniciei a Saudação');
}